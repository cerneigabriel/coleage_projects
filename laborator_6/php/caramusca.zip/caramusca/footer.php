<footer>
    &copy; Copyright Laborator CFBC
</footer>