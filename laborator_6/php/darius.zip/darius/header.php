<div class="header">
    <h1 style="margin: 0;">header</h1>
    <ul>
        <li>
            <a>Link unu</a>
        </li>
        <li>
            <a>Link doi</a>
        </li>
        <li>
            <a>Link trei</a>
        </li>
        <li>
            <a>Link patru</a>
        </li>
    </ul>
</div>