<!DOCTYPE html>
<html>

<head>
    <title>Quiz test</title>
    <link rel="stylesheet" href="bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="info">
                    <h1>QUIZ TEST</h1>
                    <form action="score.php" method="post">
                        <h5>Intrebarea 1 : Capitala Moldovei? </h5>
                        <div class="form-group">
                            <ol>
                                <li>
                                    <input type="radio" name="q1" value="1" />Chisinau
                                </li>
                                <li>
                                    <input type="radio" name="q1" value="2" />Balti
                                </li>
                                <li>
                                    <input type="radio" name="q1" value="3" />Soroca
                                </li>
                            </ol>
                        </div>
                        <br />
                        <div class="form-group">
                            <h5>Intrebarea 2 : Din ce an Moldova este o tara independenta?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q2" value="1" />1999
                                </li>
                                <li>
                                    <input type="radio" name="q2" value="2" />1992
                                </li>
                                <li>
                                    <input type="radio" name="q2" value="3" />1991
                                </li>
                            </ol>
                        </div>
                        <br />
                        <div class="form-group">
                            <h5>Intrebarea 3 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q3" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q3" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q3" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 4 : Cat este 2+3?</h5>
                            <input type="number" name="q4">
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 5 : Chisinau este capitala carei tari?</h5>
                            <input type="text" name="q5" />
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 6 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="checkbox" name="q6" value="1" /> 2019
                                </li>
                                <li>
                                    <input type="checkbox" name="q6" value="2" /> 2020
                                </li>
                                <li>
                                    <input type="checkbox" name="q6" value="3" /> 2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 7 : Cat este 10*2?</h5>
                            <ol>
                                <li>
                                    <input type="checkbox" name="q7" value="1" id="1"> 16
                                </li>
                                <li>
                                    <input type="checkbox" name="q7" value="2" id="2"> 30
                                </li>
                                <li>
                                    <input type="checkbox" name="q7" value="3" id="3"> 20
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 8 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q8" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q8" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q8" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 9 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q9" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q9" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q9" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 10 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q10" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q10" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q10" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 11 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q11" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q11" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q11" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 12 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q12" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q12" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q12" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 13 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q13" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q13" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q13" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 14 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q14" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q14" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q14" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 15 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q15" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q15" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q15" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <h5>Intrebarea 16 : Ce an este acum?</h5>
                            <ol>
                                <li>
                                    <input type="radio" name="q16" value="1" />2019
                                </li>
                                <li>
                                    <input type="radio" name="q16" value="2" />2020
                                </li>
                                <li>
                                    <input type="radio" name="q16" value="3" />2021
                                </li>
                            </ol>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Trimite</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>