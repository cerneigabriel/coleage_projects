<?php

date_default_timezone_set("Europe/Moscow");

include_once "classes/Person.php";
include_once "classes/Employee.php";
include_once "classes/Student.php";
